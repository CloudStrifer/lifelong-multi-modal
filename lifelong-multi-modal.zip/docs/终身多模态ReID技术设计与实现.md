# 无样本重放终身多模态 ReID：技术设计与实现

## 1. 文档目的

本文档说明在 MDReID 基础上新增的无样本重放终身多模态 ReID 框架，包括实验协议、两项核心方法、代码改动、评测指标、参数增长、输出文件和运行方式。

当前版本只正式报告以下四种模态匹配场景：

- `RNT→RNT`
- `R→R`
- `N→N`
- `T→T`

每种场景报告 `mAP、Rank-1、Rank-5、Rank-10`。持续学习汇总报告 `Average Seen` 和 `Forgetting`。其余 45 种 any-to-any 组合暂不计算，在结果 JSON 的 `reserved_any_to_any` 中保留为 `null`，后续可直接扩展。

## 2. 问题定义

设终身任务序列为：

\[
\mathcal{D}_1 \rightarrow \mathcal{D}_2 \rightarrow \cdots \rightarrow \mathcal{D}_T.
\]

每个样本包含配准的 RGB、近红外和热红外图像：

\[
x=(x_R,x_N,x_T).
\]

训练任务 \(\mathcal{D}_t\) 时，只允许读取当前任务的训练集。不保存或重放旧训练图像、旧图像特征、身份原型或生成样本。允许保留模型参数、历史 Adapter 和训练身份分类头。旧任务的 query/gallery 只能用于阶段性评测，不能参与损失、超参数选择或 checkpoint 选择。

本实现采用固定 epoch 训练，并保存该阶段最后一个模型。测试集不用于选择“最佳 epoch”。

## 3. Track 定义

### Track A：行人域持续学习

```text
RGBNT201 → Market-MM
```

### Track B：车辆域持续学习

```text
RGBNT100 → MSVR310 → WMVeID863
```

### Track C：行人和车辆统一持续学习

类别集中顺序 `grouped`：

```text
RGBNT201 → Market-MM → RGBNT100 → MSVR310 → WMVeID863
```

用户指定交替顺序 `interleaved`：

```text
RGBNT201 → RGBNT100 → Market-MM → MSVR310 → WMVeID863
```

增强交替顺序 `alternate`：

```text
RGBNT100 → RGBNT201 → MSVR310 → Market-MM → WMVeID863
```

Track A 和 Track B 不增加反向顺序。

## 4. 总体架构

```mermaid
flowchart LR
    X["当前任务三模态样本<br/>R / N / T"] --> B["冻结的共享 CLIP ViT-B/16"]
    B --> AR["A(t,R)<br/>逐层低秩 Adapter"]
    B --> AN["A(t,N)<br/>逐层低秩 Adapter"]
    B --> AT["A(t,T)<br/>逐层低秩 Adapter"]
    AR --> FR["R 私有/共享特征"]
    AN --> FN["N 私有/共享特征"]
    AT --> FT["T 私有/共享特征"]
    FR --> L["ID + Triplet + 跨光谱一致性损失"]
    FN --> L
    FT --> L
    FR --> G["跨光谱一致性路由"]
    FN --> G
    FT --> G
    G --> K["自动选择历史任务 Bank"]
    K --> E["RNT/R/N/T 检索描述子"]
```

共享主干始终只有一份。模型增长来自任务私有 Adapter 和训练身份分类头，而不是为每个数据集复制完整模型。

## 5. 创新点一：任务–模态解耦 Adapter Bank

### 5.1 结构

在 CLIP ViT 的每个 Transformer block 中，为任务 \(t\) 和模态 \(m\in\{R,N,T\}\) 建立一个低秩瓶颈 Adapter：

\[
A_{t,m}(h)=W^{up}_{t,m}\,\sigma\left(W^{down}_{t,m}h\right).
\]

Transformer block 使用并联残差形式：

\[
h'=h+\mathrm{MSA}(\mathrm{LN}(h)),
\]

\[
h^{out}=h'+\mathrm{MLP}(\mathrm{LN}(h'))
 A_{t,m}(\mathrm{LN}(h')).
\]

因此知识在两个轴上解耦：

- 任务轴：不同数据集使用不同 Adapter Bank；
- 模态轴：同一任务的 R、N、T 使用三个独立 Adapter。

MDReID 原方法主要解决单任务内的模态私有/共享信息解耦；本实现进一步解决持续任务之间、以及任务内部不同光谱之间的知识组织。

### 5.2 冻结与更新规则

学习任务 \(t\) 时：

- 冻结 CLIP 共享主干；
- 冻结所有历史任务 Adapter；
- 冻结历史任务分类头；
- 只更新当前任务的 R/N/T Adapter 和当前分类头。

这属于参数隔离型持续学习。虽然 Oracle task ID 下历史 Adapter 不发生参数遗忘，但仍然满足任务顺序到达、旧训练数据不可访问和单一共享主干的持续学习定义。自动路由设置下，新增专家还可能产生路由干扰，因此实际阶段性能和 Forgetting 仍需测量。

### 5.3 历史同模态知识初始化

为避免“每个任务完全独立、无法前向迁移”，新任务 Adapter 默认由历史同模态 Adapter 均值初始化：

\[
A^{(0)}_{t,m}=
\frac{1}{t-1}\sum_{k=1}^{t-1}A_{k,m}.
\]

随后只优化新任务参数，可写成：

\[
A_{t,m}=A^{(0)}_{t,m}+\Delta A_{t,m}.
\]

配置项 `LIFELONG.ADAPTER_INIT` 支持：

- `mean`：所有历史同模态 Adapter 均值，当前默认；
- `latest`：最近任务同模态 Adapter；
- `zero`：不从历史任务复制。

这使方法同时具备旧知识隔离和新任务前向迁移。

### 5.4 参数增长

设 Transformer 隐藏维度为 \(d\)，Adapter rank 为 \(r\)，层数为 \(L\)。单个含偏置 Adapter 的参数量为：

\[
P_A=2dr+d+r.
\]

每个任务有三模态、每层各一个 Adapter：

\[
\Delta P_{\mathrm{task}}=3L(2dr+d+r).
\]

CLIP ViT-B/16 中 \(d=768,L=12\)。默认 \(r=64\) 时：

\[
\Delta P_{\mathrm{task}}=3,568,896,
\]

约为每任务 3.57M Adapter 参数。当前任务分类头额外增加：

\[
P_{\mathrm{head}}=3\times512\times C_t,
\]

其中 \(C_t\) 是当前任务训练身份数。

代码在每个阶段记录：

- 总参数；
- 当前可训练参数；
- Adapter 总参数及每任务增量；
- 分类头总参数及每任务增量；
- 共享主干参数；
- FP32/FP16 理论存储量。

建议论文同时报告 `r∈{16,32,64,128}` 的性能–参数权衡。

## 6. 创新点二：跨光谱一致性自动路由

### 6.1 多模态输入路由

推理时不直接提供数据集/任务标签。对候选任务 Bank \(k\)，分别获得可用模态特征 \(f_{k,m}\)。当至少有两个模态时，计算跨光谱一致性：

\[
C_k=\frac{1}{|\mathcal{P}|}
\sum_{(i,j)\in\mathcal{P}}
\cos(f_{k,i},f_{k,j}).
\]

其中 \(\mathcal{P}\) 是当前可用模态的两两组合。RNT 输入包含 `R-N、R-T、N-T` 三项。

### 6.2 单模态回退

`R→R、N→N、T→T` 只有一个模态，不能计算跨光谱两两一致性。因此使用历史任务身份分类头的归一化置信度作为无样本回退分数：

\[
Q_k=1-\frac{H(p_k)}{\log C_k},
\]

其中 \(p_k\) 是候选 Bank 对应分类头的 softmax，\(C_k\) 为该任务训练身份数。

综合路由分数为：

\[
S_k=\lambda_c C_k+\lambda_h Q_k.
\]

当前配置为 \(\lambda_c=1.0,\lambda_h=0.1\)。单模态时只使用 \(Q_k\)。最终逐样本选择：

\[
k^*=\arg\max_k S_k.
\]

自动路由不保存旧样本或旧特征原型。历史分类头属于模型参数，其参数量已纳入增长统计。

### 6.3 Auto 与 Oracle

- `auto`：主实验设置，不输入任务标签；
- `oracle`：诊断上界，直接使用样本所属任务的 Adapter Bank。

建议论文同时给出 Auto/Oracle 差值，以分离“表征质量”和“路由错误”两个因素。输出中的 `routing_accuracy` 仅用于分析，不参与训练。

## 7. 特征与训练目标

每个模态使用 CLIP class token 作为私有特征，并使用 MDReID 增加的共享图像 token 作为共享特征：

\[
z_m=[z_m^{private},z_m^{shared}].
\]

四种场景的描述子为：

\[
z_{RNT}=[z_R,z_N,z_T],\quad
z_R=z_R,\quad z_N=z_N,\quad z_T=z_T.
\]

训练损失为：

\[
\mathcal{L}
=\lambda_{id}\mathcal{L}_{id}
+\lambda_{tri}\mathcal{L}_{tri}
+\lambda_{con}\mathcal{L}_{con}.
\]

- \(\mathcal{L}_{id}\)：三个模态身份分类损失的平均；
- \(\mathcal{L}_{tri}\)：三个单模态 Triplet 与 RNT 融合 Triplet；
- \(\mathcal{L}_{con}\)：同一样本三个光谱描述子的余弦一致性；
- 默认 \(\lambda_{id}=0.25,\lambda_{tri}=1.0,\lambda_{con}=0.1\)。

## 8. 原生尺寸与动态二维位置编码

不将所有数据强制拉伸或填充为正方形：

- 行人数据：`[H,W]=[256,128]`；
- 车辆数据：`[H,W]=[128,256]`。

Patch size 为 16 时，两类输入均包含 128 个 patch，但二维网格不同：

- 行人：`16×8`；
- 车辆：`8×16`。

实现会把位置编码拆成特殊 token 与 patch 网格。特殊 token 保持不变，patch 网格按当前输入的实际 `grid_h×grid_w` 使用 bicubic 插值，然后重新拼接。这样即使 patch 总数相同，也不会错误复用相反的二维几何位置。

动态插值不新增任务参数。三模态的随机翻转、padding 和 crop 使用相同随机参数，避免破坏配准关系。

## 9. 五个数据集的本地协议

| 数据集 | 训练 ID/样本 | Query ID/样本 | Gallery ID/样本 | 目标尺寸 |
|---|---:|---:|---:|---|
| RGBNT201 | 171 / 3,951 | 30 / 836 | 30 / 836 | 256×128 |
| Market-MM | 751 / 12,936 | 750 / 3,368 | 过滤 `pid=-1` 后 751 / 15,913 | 256×128 |
| RGBNT100 | 50 / 8,675 | 50 / 1,715 | 50 / 8,575 | 128×256 |
| MSVR310 | 155 / 1,032 | 52 / 591 | 155 / 1,055 | 128×256 |
| WMVeID863 local-clean-v1 | 596 / 3,441 | 210 / 968 | 272 / 1,226 | 128×256 |

### 9.1 RGBNT100

本地文件是 `768×128` 横向拼接图，按以下位置切分：

- R：`[0:256]`；
- N：`[256:512]`；
- T：`[512:768]`。

切分后按车辆目标尺寸 `128×256` 输入。

### 9.2 MSVR310

使用 `query3`；如果不存在则回退到 `query`。评测时移除相同身份、相同 scene 的 gallery 项，与仓库现有 MSVR310 协议一致。

### 9.3 WMVeID863 local-clean-v1

以本地目录为唯一事实来源，不依赖论文中无法与本地文件对应的数量描述。

规则如下：

1. `vis` 为样本锚点；
2. 同名文件必须同时存在于 `vis/ni/th`；
3. 缺少任一模态的样本直接排除；
4. 仅出现在 `ni/th` 的孤立文件忽略；
5. 从训练集排除与 test 重叠的 7 个身份：
   `0325、0331、0397、0406、0451、0471、0862`；
6. 本地审计后还排除了 1 个无法精确可靠配对的训练样本；
7. 首次训练自动生成相对路径 manifest：
   `OUTPUT_DIR/track_*/protocols/WMVeID863_local-clean-v1.json`。

manifest 可从 Windows 复制到 Ubuntu，只要 `DATASETS.ROOT_DIR/WMVEID863` 内部相对结构不变。

## 10. 评测和持续学习指标

每完成一个任务，评测所有已学习数据集，但不据此回滚或选择模型。

每个数据集、每种场景报告：

- mAP；
- Rank-1；
- Rank-5；
- Rank-10；
- routing accuracy。

第 \(t\) 阶段某项指标的 Average Seen：

\[
A_t=\frac{1}{t}\sum_{j=1}^{t}a_{t,j}.
\]

第 \(t\) 阶段的 Forgetting：

\[
F_t=\frac{1}{t-1}\sum_{j=1}^{t-1}
\left(\max_{l<t}a_{l,j}-a_{t,j}\right).
\]

第一阶段 Forgetting 定义为 0。若当前性能超过历史最好值，单任务遗忘项可以为负，代表正向后向迁移，不强制截断为 0。

代码对 mAP、R1、R5、R10 分别计算 Average Seen 和 Forgetting。

## 11. 代码改动

### 新增文件

- `data/lifelong_datasets.py`
  - 五数据集统一三模态协议；
  - WMVeID863 manifest；
  - 人员/车辆原生宽高；
  - 三模态同步几何增强；
  - Windows/Linux 可移植路径。
- `modeling/lifelong_model.py`
  - 任务–模态 Adapter Bank；
  - 历史同模态初始化；
  - 自动/Oracle 路由；
  - RNT/R/N/T 描述子；
  - 参数增长统计。
- `engine/lifelong_trainer.py`
  - Track A/B/C；
  - 固定轮数、无重放顺序训练；
  - 四场景联合高效评测；
  - Average Seen/Forgetting；
  - JSON/CSV/checkpoint 输出。
- `train_lifelong.py`
  - 持续训练入口。
- `test_lifelong.py`
  - checkpoint 独立测试入口。
- `configs/lifelong/MDReID_TMDA_CSCR.yml`
  - 持续学习默认配置。

### 修改文件

- `modeling/clip/model.py`
  - 在每个 Transformer block 中加入任务–模态低秩 Adapter；
  - 加入动态二维位置编码插值；
  - 保持原 MDReID 分支在未指定 `task_key` 时不变。
- `modeling/meta_arch.py`
  - 向 CLIP 主干传递 `task_key/modality`；
  - 移除构造阶段硬编码 `.to(cuda)`，由训练入口统一管理设备。
- `config/defaults.py`
  - 增加 `LIFELONG` 配置树。

原有 `train_net.py/test_net.py/make_dataloader` 保留，仍可用于复现原单数据集 MDReID。

## 12. 输出文件

以 Track C grouped 为例：

```text
outputs/lifelong/track_C_grouped/
├── checkpoints/
│   ├── stage_01_rgbnt201.pth
│   ├── stage_02_market_mm.pth
│   ├── ...
│   └── stage_05_wmveid863.pth
├── protocols/
│   └── WMVeID863_local-clean-v1.json
├── continual_results.json
├── stage_metrics.csv
├── continual_summary.csv
├── train_log.txt
└── test_auto_stage_05.json
```

`continual_results.json` 中未启用的 any-to-any 场景保留为空，不会被误计入平均值。

## 13. 运行命令

### 13.1 Ubuntu 训练

先将 `MODEL.PRETRAIN_PATH_T` 指向 CLIP ViT-B/16 权重。以下命令用命令行覆盖路径：

```bash
CUDA_VISIBLE_DEVICES=0 python train_lifelong.py \
  --config_file configs/lifelong/MDReID_TMDA_CSCR.yml \
  --track A \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  OUTPUT_DIR ./outputs/lifelong \
  DATALOADER.NUM_WORKERS 8
```

Track B：

```bash
CUDA_VISIBLE_DEVICES=0 python train_lifelong.py \
  --config_file configs/lifelong/MDReID_TMDA_CSCR.yml \
  --track B \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8
```

Track C 三种顺序：

```bash
CUDA_VISIBLE_DEVICES=0 python train_lifelong.py --track C --order grouped \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8

CUDA_VISIBLE_DEVICES=0 python train_lifelong.py --track C --order interleaved \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8

CUDA_VISIBLE_DEVICES=0 python train_lifelong.py --track C --order alternate \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8
```

未写 `--config_file` 时默认使用持续学习配置。

### 13.2 Ubuntu 测试

Auto 路由主结果：

```bash
CUDA_VISIBLE_DEVICES=0 python test_lifelong.py \
  --checkpoint outputs/lifelong/track_C_grouped/checkpoints/stage_05_wmveid863.pth \
  --routing auto \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8
```

Oracle 路由诊断上界：

```bash
CUDA_VISIBLE_DEVICES=0 python test_lifelong.py \
  --checkpoint outputs/lifelong/track_C_grouped/checkpoints/stage_05_wmveid863.pth \
  --routing oracle \
  DATASETS.ROOT_DIR /data/reid/dataset \
  MODEL.PRETRAIN_PATH_T /data/reid/pretrain_model/ViT-B-16.pt \
  DATALOADER.NUM_WORKERS 8
```

### 13.3 Windows 快速调试

PowerShell：

```powershell
$env:CUDA_VISIBLE_DEVICES='0'
python train_lifelong.py `
  --config_file configs/lifelong/MDReID_TMDA_CSCR.yml `
  --track A `
  DATASETS.ROOT_DIR ./dataset `
  MODEL.PRETRAIN_PATH_T D:/models/ViT-B-16.pt `
  SOLVER.MAX_EPOCHS 1 `
  SOLVER.IMS_PER_BATCH 16 `
  TEST.IMS_PER_BATCH 32 `
  DATALOADER.NUM_WORKERS 0
```

Windows 调试完成后，正式结果应统一在 Ubuntu、相同 CUDA/PyTorch 环境和固定随机种子下运行。

## 14. 建议的论文消融

至少包含以下对照：

1. 原 MDReID 单任务上界；
2. 共享一组三模态 Adapter、所有任务连续更新；
3. 每任务三模态隔离 Adapter，Oracle task ID；
4. Adapter Bank + Auto 路由；
5. 去掉历史 Adapter 初始化；
6. 去掉跨光谱一致性训练损失；
7. 去掉路由的一致性项或置信度项；
8. rank 与参数增长消融；
9. Auto 与 Oracle 的路由差距；
10. 与“每任务保存一份完整模型”的参数量和性能对比。

## 15. 当前边界

- 当前只实现和正式统计 `RNT→RNT、R→R、N→N、T→T`；
- 其余 any-to-any 场景仅预留结果槽；
- 单模态自动路由依赖历史分类头的归一化置信度，属于需要重点消融验证的设计；
- 参数隔离使 Oracle 设置下参数遗忘接近零，论文重点应同时强调无重放前向迁移、自动路由、统一人车序列以及性能–参数增长权衡；
- 正式论文结果必须在完整 CLIP 预训练权重和目标 Ubuntu GPU 环境中重新运行，不应使用 Windows CPU 调试结果。
