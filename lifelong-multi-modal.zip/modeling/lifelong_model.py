"""Task-modality adapter bank and task-agnostic routing for lifelong MDReID."""

from __future__ import annotations

import math
from itertools import combinations
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from modeling.meta_arch import build_transformer


MODALITIES = ("R", "N", "T")
SCENARIO_MODALITIES = {
    "RNT": ("R", "N", "T"),
    "R": ("R",),
    "N": ("N",),
    "T": ("T",),
}


class TaskIdentityHeads(nn.Module):
    """Training heads retained to provide a no-replay single-modal routing score."""

    def __init__(self, feature_dim: int, num_classes: int):
        super().__init__()
        self.num_classes = int(num_classes)
        self.classifiers = nn.ModuleDict({
            modality: nn.Linear(feature_dim, num_classes, bias=False)
            for modality in MODALITIES
        })
        for classifier in self.classifiers.values():
            nn.init.normal_(classifier.weight, std=0.001)

    def forward(self, modality: str, feature: torch.Tensor) -> torch.Tensor:
        return self.classifiers[modality](feature)


class LifelongMDReID(nn.Module):
    """One frozen CLIP backbone plus a growing task x modality adapter bank."""

    def __init__(self, cfg):
        super().__init__()
        if cfg.MODEL.TRANSFORMER_TYPE != "ViT-B-16":
            raise ValueError(
                "The lifelong adapter bank currently requires MODEL.TRANSFORMER_TYPE='ViT-B-16'."
            )
        if cfg.MODEL.PROMPT or cfg.MODEL.ADAPTER:
            raise ValueError(
                "Disable the legacy PROMPT/ADAPTER flags when using the lifelong adapter bank."
            )
        if cfg.MODEL.SIE_CAMERA:
            raise ValueError(
                "Set MODEL.SIE_CAMERA=False: camera vocabularies differ across lifelong tasks."
            )
        self.cfg = cfg
        self.feature_dim = 512
        self.add_share = bool(cfg.MODEL.ADD_SHARE)
        self.backbone = build_transformer(
            num_classes=1,
            cfg=cfg,
            camera_num=0,
            view_num=0,
            factory={},
            feat_dim=self.feature_dim,
        )
        self.task_heads = nn.ModuleDict()
        self.task_order: List[str] = []
        self.task_num_classes: Dict[str, int] = {}
        self.adapter_rank = int(cfg.LIFELONG.ADAPTER_RANK)
        self.adapter_dropout = float(cfg.LIFELONG.ADAPTER_DROPOUT)
        self.adapter_init = str(cfg.LIFELONG.ADAPTER_INIT).lower()
        self.consistency_weight = float(cfg.LIFELONG.ROUTER.CONSISTENCY_WEIGHT)
        self.confidence_weight = float(cfg.LIFELONG.ROUTER.CONFIDENCE_WEIGHT)
        for parameter in self.backbone.parameters():
            parameter.requires_grad = False

    @property
    def visual(self):
        return self.backbone.base

    def register_task(
        self,
        task_key: str,
        num_classes: int,
        initialize_from_history: bool = True,
    ) -> None:
        if task_key in self.task_heads:
            if self.task_num_classes[task_key] != int(num_classes):
                raise ValueError("Task {} was registered with a different class count.".format(task_key))
            return
        if "." in task_key:
            raise ValueError("Task keys cannot contain '.': {}".format(task_key))
        source_tasks: List[str] = []
        if initialize_from_history and self.task_order:
            if self.adapter_init == "mean":
                source_tasks = list(self.task_order)
            elif self.adapter_init == "latest":
                source_tasks = [self.task_order[-1]]
            elif self.adapter_init not in ("zero", "random"):
                raise ValueError("Unknown LIFELONG.ADAPTER_INIT: {}".format(self.adapter_init))
        self.visual.add_lifelong_task(
            task_key=task_key,
            bottleneck_dim=self.adapter_rank,
            dropout=self.adapter_dropout,
            init_from=source_tasks,
        )
        self.task_heads[task_key] = TaskIdentityHeads(self.feature_dim, num_classes)
        self.task_order.append(task_key)
        self.task_num_classes[task_key] = int(num_classes)
        device = next(self.backbone.parameters()).device
        self.to(device)
        self.set_trainable_task(task_key)

    def set_trainable_task(self, task_key: str) -> None:
        if task_key not in self.task_heads:
            raise KeyError("Unregistered task: {}".format(task_key))
        for parameter in self.parameters():
            parameter.requires_grad = False
        adapter_marker = ".lifelong_adapters.{}.".format(task_key)
        for name, parameter in self.named_parameters():
            if adapter_marker in name or name.startswith("task_heads.{}.".format(task_key)):
                parameter.requires_grad = True

    def trainable_parameters(self) -> Iterable[nn.Parameter]:
        return (parameter for parameter in self.parameters() if parameter.requires_grad)

    def _encode_task(
        self,
        images: Dict[str, torch.Tensor],
        task_key: str,
        modalities: Sequence[str],
    ) -> Dict[str, Dict[str, torch.Tensor]]:
        encoded: Dict[str, Dict[str, torch.Tensor]] = {}
        for modality in modalities:
            tokens, private_feature = self.backbone(
                images[modality],
                cam_label=None,
                view_label=None,
                modality=modality,
                task_key=task_key,
            )
            shared_feature = tokens[:, 0] if self.add_share else private_feature
            descriptor = torch.cat([private_feature, shared_feature], dim=1)
            logits = self.task_heads[task_key](modality, private_feature)
            encoded[modality] = {
                "private": private_feature,
                "shared": shared_feature,
                "descriptor": descriptor,
                "logits": logits,
            }
        return encoded

    @staticmethod
    def _compose_descriptor(
        encoded: Dict[str, Dict[str, torch.Tensor]],
        modalities: Sequence[str],
    ) -> torch.Tensor:
        return torch.cat([encoded[modality]["descriptor"] for modality in modalities], dim=1)

    def forward_train(self, images: Dict[str, torch.Tensor], task_key: str):
        encoded = self._encode_task(images, task_key, MODALITIES)
        return {
            "modalities": encoded,
            "fused": self._compose_descriptor(encoded, MODALITIES),
        }

    @staticmethod
    def _normalized_classifier_confidence(logits: torch.Tensor) -> torch.Tensor:
        if logits.shape[1] <= 1:
            return torch.zeros(logits.shape[0], device=logits.device, dtype=logits.dtype)
        probabilities = F.softmax(logits.float(), dim=1)
        entropy = -(probabilities * probabilities.clamp_min(1e-12).log()).sum(dim=1)
        return (1.0 - entropy / math.log(logits.shape[1])).to(dtype=logits.dtype)

    def _routing_score(
        self,
        encoded: Dict[str, Dict[str, torch.Tensor]],
        modalities: Sequence[str],
    ) -> torch.Tensor:
        confidence = torch.stack([
            self._normalized_classifier_confidence(encoded[modality]["logits"])
            for modality in modalities
        ]).mean(dim=0)
        if len(modalities) < 2:
            return confidence
        pair_scores = []
        for left, right in combinations(modalities, 2):
            left_feature = F.normalize(encoded[left]["descriptor"].float(), dim=1)
            right_feature = F.normalize(encoded[right]["descriptor"].float(), dim=1)
            pair_scores.append((left_feature * right_feature).sum(dim=1))
        consistency = torch.stack(pair_scores).mean(dim=0)
        return self.consistency_weight * consistency + self.confidence_weight * confidence.float()

    def extract(
        self,
        images: Dict[str, torch.Tensor],
        scenario: str,
        routing: str = "auto",
        oracle_task: Optional[str] = None,
        candidate_tasks: Optional[Sequence[str]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Extract a descriptor and return selected bank indices and router scores."""
        scenario = scenario.upper()
        if scenario not in SCENARIO_MODALITIES:
            raise KeyError("Scenario {} is not enabled.".format(scenario))
        modalities = SCENARIO_MODALITIES[scenario]
        candidates = list(candidate_tasks or self.task_order)
        if not candidates:
            raise RuntimeError("No task adapters have been registered.")
        unknown = [task for task in candidates if task not in self.task_heads]
        if unknown:
            raise KeyError("Unknown candidate tasks: {}".format(unknown))

        if routing == "oracle":
            if oracle_task is None:
                raise ValueError("oracle_task is required for oracle routing.")
            encoded = self._encode_task(images, oracle_task, modalities)
            descriptor = self._compose_descriptor(encoded, modalities)
            selected = torch.full(
                (descriptor.shape[0],),
                candidates.index(oracle_task),
                dtype=torch.long,
                device=descriptor.device,
            )
            scores = torch.zeros(
                descriptor.shape[0], len(candidates), device=descriptor.device
            )
            scores[:, candidates.index(oracle_task)] = 1.0
            return descriptor, selected, scores
        if routing != "auto":
            raise ValueError("routing must be 'auto' or 'oracle', got {}".format(routing))

        candidate_descriptors = []
        candidate_scores = []
        for task_key in candidates:
            encoded = self._encode_task(images, task_key, modalities)
            candidate_descriptors.append(self._compose_descriptor(encoded, modalities))
            candidate_scores.append(self._routing_score(encoded, modalities))
        descriptors = torch.stack(candidate_descriptors, dim=0)
        scores = torch.stack(candidate_scores, dim=1)
        selected = scores.argmax(dim=1)
        batch_indices = torch.arange(scores.shape[0], device=scores.device)
        descriptor = descriptors[selected, batch_indices]
        return descriptor, selected, scores

    def extract_scenarios(
        self,
        images: Dict[str, torch.Tensor],
        scenarios: Sequence[str],
        routing: str = "auto",
        oracle_task: Optional[str] = None,
        candidate_tasks: Optional[Sequence[str]] = None,
    ) -> Dict[str, Tuple[torch.Tensor, torch.Tensor, torch.Tensor]]:
        """Extract several scenarios while encoding each task/modality only once."""
        normalized_scenarios = [str(scenario).upper() for scenario in scenarios]
        for scenario in normalized_scenarios:
            if scenario not in SCENARIO_MODALITIES:
                raise KeyError("Scenario {} is not enabled.".format(scenario))
        required_modalities = tuple(
            modality
            for modality in MODALITIES
            if any(modality in SCENARIO_MODALITIES[scenario] for scenario in normalized_scenarios)
        )
        candidates = list(candidate_tasks or self.task_order)
        if not candidates:
            raise RuntimeError("No task adapters have been registered.")
        if routing == "oracle":
            if oracle_task is None:
                raise ValueError("oracle_task is required for oracle routing.")
            encoded = self._encode_task(images, oracle_task, required_modalities)
            oracle_index = candidates.index(oracle_task)
            outputs = {}
            for scenario in normalized_scenarios:
                modalities = SCENARIO_MODALITIES[scenario]
                descriptor = self._compose_descriptor(encoded, modalities)
                selected = torch.full(
                    (descriptor.shape[0],),
                    oracle_index,
                    dtype=torch.long,
                    device=descriptor.device,
                )
                scores = torch.zeros(
                    descriptor.shape[0], len(candidates), device=descriptor.device
                )
                scores[:, oracle_index] = 1.0
                outputs[scenario] = descriptor, selected, scores
            return outputs
        if routing != "auto":
            raise ValueError("routing must be 'auto' or 'oracle', got {}".format(routing))

        encoded_candidates = {
            task_key: self._encode_task(images, task_key, required_modalities)
            for task_key in candidates
        }
        outputs = {}
        for scenario in normalized_scenarios:
            modalities = SCENARIO_MODALITIES[scenario]
            descriptor_stack = torch.stack([
                self._compose_descriptor(encoded_candidates[task_key], modalities)
                for task_key in candidates
            ])
            score_stack = torch.stack([
                self._routing_score(encoded_candidates[task_key], modalities)
                for task_key in candidates
            ], dim=1)
            selected = score_stack.argmax(dim=1)
            batch_indices = torch.arange(score_stack.shape[0], device=score_stack.device)
            outputs[scenario] = (
                descriptor_stack[selected, batch_indices],
                selected,
                score_stack,
            )
        return outputs

    def parameter_accounting(self) -> Dict[str, object]:
        total = sum(parameter.numel() for parameter in self.parameters())
        trainable = sum(parameter.numel() for parameter in self.parameters() if parameter.requires_grad)
        adapter_counts = {}
        head_counts = {}
        for task_key in self.task_order:
            marker = ".lifelong_adapters.{}.".format(task_key)
            adapter_counts[task_key] = sum(
                parameter.numel()
                for name, parameter in self.named_parameters()
                if marker in name
            )
            head_counts[task_key] = sum(
                parameter.numel() for parameter in self.task_heads[task_key].parameters()
            )
        adapter_total = sum(adapter_counts.values())
        head_total = sum(head_counts.values())
        return {
            "total": total,
            "trainable_current": trainable,
            "frozen_shared_and_other": total - trainable,
            "adapter_total": adapter_total,
            "head_total": head_total,
            "shared_backbone_and_tokens": total - adapter_total - head_total,
            "adapter_per_task": adapter_counts,
            "head_per_task": head_counts,
            "fp32_megabytes": total * 4 / (1024 ** 2),
            "fp16_megabytes": total * 2 / (1024 ** 2),
        }
