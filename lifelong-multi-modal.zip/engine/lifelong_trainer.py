"""Training, evaluation, and reporting for exemplar-free lifelong MDReID."""

from __future__ import annotations

import csv
import json
import logging
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from data.lifelong_datasets import (
    MODALITIES,
    TaskDataLoaders,
    build_task_dataloaders,
    canonical_dataset_name,
    dataset_task_key,
)
from layers.softmax_loss import LabelSmoothingCrossEntropy
from layers.triplet_loss import TripletLoss
from modeling.lifelong_model import LifelongMDReID


TRACKS = {
    "A": {
        "default": ["RGBNT201", "Market-MM"],
    },
    "B": {
        "default": ["RGBNT100", "MSVR310", "WMVeID863"],
    },
    "C": {
        "grouped": ["RGBNT201", "Market-MM", "RGBNT100", "MSVR310", "WMVeID863"],
        "interleaved": ["RGBNT201", "RGBNT100", "Market-MM", "MSVR310", "WMVeID863"],
        "alternate": ["RGBNT100", "RGBNT201", "MSVR310", "Market-MM", "WMVeID863"],
    },
}


def resolve_track(track: str, order: str) -> List[str]:
    track = track.upper()
    if track not in TRACKS:
        raise KeyError("Unknown track: {}".format(track))
    orders = TRACKS[track]
    key = order.lower() if track == "C" else "default"
    if key not in orders:
        raise KeyError("Track {} does not define order {}.".format(track, order))
    return list(orders[key])


def set_reproducible_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def resolve_device(cfg) -> torch.device:
    if str(cfg.MODEL.DEVICE).lower() == "cuda" and torch.cuda.is_available():
        return torch.device("cuda:{}".format(cfg.MODEL.DEVICE_ID))
    return torch.device("cpu")


def _move_images(images: Dict[str, torch.Tensor], device: torch.device):
    return {
        modality: tensor.to(device, non_blocking=True)
        for modality, tensor in images.items()
    }


def _build_optimizer(cfg, model: LifelongMDReID):
    parameters = list(model.trainable_parameters())
    if not parameters:
        raise RuntimeError("No trainable parameters for the current task.")
    name = str(cfg.SOLVER.OPTIMIZER_NAME).lower()
    if name == "adamw":
        return torch.optim.AdamW(
            parameters,
            lr=cfg.SOLVER.BASE_LR,
            weight_decay=cfg.SOLVER.WEIGHT_DECAY,
        )
    if name == "adam":
        return torch.optim.Adam(
            parameters,
            lr=cfg.SOLVER.BASE_LR,
            weight_decay=cfg.SOLVER.WEIGHT_DECAY,
        )
    if name == "sgd":
        return torch.optim.SGD(
            parameters,
            lr=cfg.SOLVER.BASE_LR,
            weight_decay=cfg.SOLVER.WEIGHT_DECAY,
            momentum=cfg.SOLVER.MOMENTUM,
        )
    raise ValueError("Unsupported lifelong optimizer: {}".format(cfg.SOLVER.OPTIMIZER_NAME))


def _cross_spectral_consistency(modal_features: Sequence[torch.Tensor]) -> torch.Tensor:
    normalized = [F.normalize(feature.float(), dim=1) for feature in modal_features]
    losses = []
    for index, left in enumerate(normalized):
        for right in normalized[index + 1 :]:
            losses.append(1.0 - (left * right).sum(dim=1).mean())
    return torch.stack(losses).mean()


def train_one_task(
    cfg,
    model: LifelongMDReID,
    task_key: str,
    train_loader,
    device: torch.device,
    logger: logging.Logger,
) -> Dict[str, float]:
    """Train only the current task bank for a fixed number of epochs."""
    model.set_trainable_task(task_key)
    model.to(device)
    optimizer = _build_optimizer(cfg, model)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, int(cfg.SOLVER.MAX_EPOCHS))
    )
    identity_loss_fn = LabelSmoothingCrossEntropy(smoothing=0.1)
    triplet_loss_fn = TripletLoss(
        None if bool(cfg.MODEL.NO_MARGIN) else float(cfg.SOLVER.MARGIN)
    )
    amp_enabled = bool(cfg.LIFELONG.AMP) and device.type == "cuda"
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)
    final_stats: Dict[str, float] = {}

    for epoch in range(1, int(cfg.SOLVER.MAX_EPOCHS) + 1):
        model.train()
        running = {"loss": 0.0, "id": 0.0, "triplet": 0.0, "consistency": 0.0}
        samples = 0
        for iteration, (images, labels, _, _, _) in enumerate(train_loader, start=1):
            images = _move_images(images, device)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad()
            with torch.cuda.amp.autocast(enabled=amp_enabled):
                output = model.forward_train(images, task_key)
                modal_outputs = output["modalities"]
                identity_loss = torch.stack([
                    identity_loss_fn(modal_outputs[modality]["logits"], labels)
                    for modality in MODALITIES
                ]).mean()
                modal_triplets = [
                    triplet_loss_fn(modal_outputs[modality]["descriptor"], labels)[0]
                    for modality in MODALITIES
                ]
                fused_triplet = triplet_loss_fn(output["fused"], labels)[0]
                triplet_loss = (torch.stack(modal_triplets).mean() + fused_triplet) / 2.0
                consistency_loss = _cross_spectral_consistency([
                    modal_outputs[modality]["descriptor"] for modality in MODALITIES
                ])
                loss = (
                    float(cfg.MODEL.ID_LOSS_WEIGHT) * identity_loss
                    + float(cfg.MODEL.TRIPLET_LOSS_WEIGHT) * triplet_loss
                    + float(cfg.LIFELONG.CONSISTENCY_LOSS_WEIGHT) * consistency_loss
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            if float(cfg.LIFELONG.GRAD_CLIP) > 0:
                torch.nn.utils.clip_grad_norm_(
                    list(model.trainable_parameters()), float(cfg.LIFELONG.GRAD_CLIP)
                )
            scaler.step(optimizer)
            scaler.update()

            batch_size = labels.shape[0]
            samples += batch_size
            running["loss"] += loss.item() * batch_size
            running["id"] += identity_loss.item() * batch_size
            running["triplet"] += triplet_loss.item() * batch_size
            running["consistency"] += consistency_loss.item() * batch_size
            if iteration % int(cfg.SOLVER.LOG_PERIOD) == 0:
                logger.info(
                    "task=%s epoch=%d/%d iter=%d/%d loss=%.4f",
                    task_key,
                    epoch,
                    cfg.SOLVER.MAX_EPOCHS,
                    iteration,
                    len(train_loader),
                    running["loss"] / max(1, samples),
                )
        scheduler.step()
        final_stats = {key: value / max(1, samples) for key, value in running.items()}
        logger.info(
            "task=%s epoch=%d fixed-schedule train loss=%.4f id=%.4f tri=%.4f consistency=%.4f",
            task_key,
            epoch,
            final_stats["loss"],
            final_stats["id"],
            final_stats["triplet"],
            final_stats["consistency"],
        )
    return final_stats


def _evaluate_rank(
    distance: np.ndarray,
    query_pids: np.ndarray,
    gallery_pids: np.ndarray,
    query_camids: np.ndarray,
    gallery_camids: np.ndarray,
    query_sceneids: np.ndarray,
    gallery_sceneids: np.ndarray,
    scene_protocol: bool,
    max_rank: int = 50,
) -> Tuple[np.ndarray, float]:
    num_query, num_gallery = distance.shape
    max_rank = min(max_rank, num_gallery)
    indices = np.argsort(distance, axis=1)
    matches = (gallery_pids[indices] == query_pids[:, None]).astype(np.int32)
    all_cmc: List[np.ndarray] = []
    all_ap: List[float] = []

    for query_index in range(num_query):
        order = indices[query_index]
        if scene_protocol:
            remove = (
                (gallery_pids[order] == query_pids[query_index])
                & (gallery_sceneids[order] == query_sceneids[query_index])
            )
        else:
            remove = (
                (gallery_pids[order] == query_pids[query_index])
                & (gallery_camids[order] == query_camids[query_index])
            )
        keep = ~remove
        raw_cmc = matches[query_index][keep]
        if not np.any(raw_cmc):
            continue
        cmc = raw_cmc.cumsum()
        cmc[cmc > 1] = 1
        clipped = cmc[:max_rank]
        if clipped.shape[0] < max_rank:
            clipped = np.pad(clipped, (0, max_rank - clipped.shape[0]), mode="edge")
        all_cmc.append(clipped)
        relevant = raw_cmc.sum()
        precision = raw_cmc.cumsum() / (np.arange(raw_cmc.shape[0]) + 1.0)
        all_ap.append(float((precision * raw_cmc).sum() / relevant))

    if not all_cmc:
        raise RuntimeError("All query identities have no valid gallery match.")
    return np.asarray(all_cmc, dtype=np.float32).mean(axis=0), float(np.mean(all_ap))


@dataclass
class EvalTask:
    dataset_name: str
    task_key: str
    loader: object
    num_query: int
    protocol_summary: Dict[str, object]


@torch.no_grad()
def evaluate_scenarios(
    model: LifelongMDReID,
    eval_task: EvalTask,
    scenarios: Sequence[str],
    candidate_tasks: Sequence[str],
    routing: str,
    device: torch.device,
) -> Dict[str, Dict[str, float]]:
    model.eval()
    scenarios = [str(scenario).upper() for scenario in scenarios]
    features = {scenario: [] for scenario in scenarios}
    selected_routes = {scenario: [] for scenario in scenarios}
    pids = []
    camids = []
    sceneids = []
    expected_index = candidate_tasks.index(eval_task.task_key)

    for images, batch_pids, batch_camids, batch_sceneids, _ in eval_task.loader:
        images = _move_images(images, device)
        outputs = model.extract_scenarios(
            images=images,
            scenarios=scenarios,
            routing=routing,
            oracle_task=eval_task.task_key if routing == "oracle" else None,
            candidate_tasks=candidate_tasks,
        )
        for scenario, (descriptor, selected, _) in outputs.items():
            features[scenario].append(descriptor.float().cpu())
            selected_routes[scenario].append(selected.cpu())
        pids.append(batch_pids.numpy())
        camids.append(batch_camids.numpy())
        sceneids.append(batch_sceneids.numpy())
    pid_array = np.concatenate(pids)
    camid_array = np.concatenate(camids)
    sceneid_array = np.concatenate(sceneids)
    results = {}
    for scenario in scenarios:
        feature_tensor = F.normalize(torch.cat(features[scenario], dim=0), dim=1)
        query_features = feature_tensor[: eval_task.num_query]
        gallery_features = feature_tensor[eval_task.num_query :]
        distance = (1.0 - query_features @ gallery_features.t()).numpy()
        cmc, mean_ap = _evaluate_rank(
            distance=distance,
            query_pids=pid_array[: eval_task.num_query],
            gallery_pids=pid_array[eval_task.num_query :],
            query_camids=camid_array[: eval_task.num_query],
            gallery_camids=camid_array[eval_task.num_query :],
            query_sceneids=sceneid_array[: eval_task.num_query],
            gallery_sceneids=sceneid_array[eval_task.num_query :],
            scene_protocol=eval_task.dataset_name == "MSVR310",
        )
        route_tensor = torch.cat(selected_routes[scenario])
        results[scenario] = {
            "mAP": mean_ap * 100.0,
            "R1": float(cmc[0]) * 100.0,
            "R5": float(cmc[min(4, len(cmc) - 1)]) * 100.0,
            "R10": float(cmc[min(9, len(cmc) - 1)]) * 100.0,
            "routing_accuracy": float(
                (route_tensor == expected_index).float().mean()
            ) * 100.0,
        }
    return results


@torch.no_grad()
def evaluate_scenario(
    model: LifelongMDReID,
    eval_task: EvalTask,
    scenario: str,
    candidate_tasks: Sequence[str],
    routing: str,
    device: torch.device,
) -> Dict[str, float]:
    return evaluate_scenarios(
        model=model,
        eval_task=eval_task,
        scenarios=[scenario],
        candidate_tasks=candidate_tasks,
        routing=routing,
        device=device,
    )[str(scenario).upper()]


def _continual_summary(
    history: Sequence[Dict[str, object]],
    current_datasets: Dict[str, Dict[str, Dict[str, float]]],
    scenarios: Sequence[str],
) -> Dict[str, Dict[str, Dict[str, float]]]:
    metrics = ("mAP", "R1", "R5", "R10")
    summary: Dict[str, Dict[str, Dict[str, float]]] = {}
    for scenario in scenarios:
        average_seen = {}
        forgetting = {}
        for metric in metrics:
            current_values = [
                scenario_results[scenario][metric]
                for scenario_results in current_datasets.values()
            ]
            average_seen[metric] = float(np.mean(current_values))
            task_forgetting = []
            for task_key, scenario_results in current_datasets.items():
                previous_values = []
                for stage in history:
                    previous_task_results = stage["datasets"].get(task_key)
                    if previous_task_results is not None:
                        previous_values.append(previous_task_results[scenario][metric])
                if previous_values:
                    task_forgetting.append(
                        max(previous_values) - scenario_results[scenario][metric]
                    )
            forgetting[metric] = float(np.mean(task_forgetting)) if task_forgetting else 0.0
        summary[scenario] = {
            "average_seen": average_seen,
            "forgetting": forgetting,
        }
    return summary


def _reserved_any_to_any() -> Dict[str, None]:
    subsets = ("R", "N", "T", "RN", "RT", "NT", "RNT")
    enabled = {"R->R", "N->N", "T->T", "RNT->RNT"}
    return {
        "{}->{}".format(query, gallery): None
        for query in subsets
        for gallery in subsets
        if "{}->{}".format(query, gallery) not in enabled
    }


def save_checkpoint(
    path: Path,
    model: LifelongMDReID,
    stage: int,
    track: str,
    order: str,
    task_specs: Sequence[Dict[str, object]],
    cfg,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "stage": stage,
            "track": track,
            "order": order,
            "task_specs": list(task_specs),
            "state_dict": model.state_dict(),
            "parameter_accounting": model.parameter_accounting(),
            "config": cfg.dump(),
        },
        str(path),
    )


def load_checkpoint_model(cfg, checkpoint_path: str, device: torch.device):
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    model = LifelongMDReID(cfg)
    for task_spec in checkpoint["task_specs"]:
        model.register_task(
            task_key=str(task_spec["task_key"]),
            num_classes=int(task_spec["num_classes"]),
            initialize_from_history=False,
        )
    incompatible = model.load_state_dict(checkpoint["state_dict"], strict=True)
    if incompatible.missing_keys or incompatible.unexpected_keys:
        raise RuntimeError("Checkpoint mismatch: {}".format(incompatible))
    model.to(device)
    return model, checkpoint


def _write_reports(output_dir: Path, report: Dict[str, object]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "continual_results.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)

    result_rows = []
    summary_rows = []
    for stage in report["stages"]:
        for task_key, task_results in stage["datasets"].items():
            for scenario, metrics in task_results.items():
                result_rows.append({
                    "stage": stage["stage"],
                    "trained_task": stage["trained_task"],
                    "eval_task": task_key,
                    "scenario": scenario,
                    **metrics,
                })
        for scenario, values in stage["continual_summary"].items():
            summary_rows.append({
                "stage": stage["stage"],
                "trained_task": stage["trained_task"],
                "scenario": scenario,
                **{
                    "average_seen_{}".format(metric): value
                    for metric, value in values["average_seen"].items()
                },
                **{
                    "forgetting_{}".format(metric): value
                    for metric, value in values["forgetting"].items()
                },
            })

    if result_rows:
        with (output_dir / "stage_metrics.csv").open(
            "w", encoding="utf-8-sig", newline=""
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=list(result_rows[0].keys()))
            writer.writeheader()
            writer.writerows(result_rows)
    if summary_rows:
        with (output_dir / "continual_summary.csv").open(
            "w", encoding="utf-8-sig", newline=""
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0].keys()))
            writer.writeheader()
            writer.writerows(summary_rows)


def _wm_manifest_path(cfg, output_dir: Path) -> str:
    if str(cfg.LIFELONG.WM_MANIFEST):
        return str(Path(cfg.LIFELONG.WM_MANIFEST).expanduser())
    return str(output_dir / "protocols" / "WMVeID863_local-clean-v1.json")


def build_cfg_dataloaders(
    cfg,
    dataset_name: str,
    output_dir: Path,
    load_train: bool,
) -> TaskDataLoaders:
    return build_task_dataloaders(
        name=dataset_name,
        root=cfg.DATASETS.ROOT_DIR,
        train_batch_size=int(cfg.SOLVER.IMS_PER_BATCH),
        test_batch_size=int(cfg.TEST.IMS_PER_BATCH),
        num_instances=int(cfg.DATALOADER.NUM_INSTANCE),
        num_workers=int(cfg.DATALOADER.NUM_WORKERS),
        mean=cfg.INPUT.PIXEL_MEAN,
        std=cfg.INPUT.PIXEL_STD,
        flip_probability=float(cfg.INPUT.PROB),
        padding=int(cfg.INPUT.PADDING),
        erasing_probability=float(cfg.INPUT.RE_PROB),
        wm_manifest_path=_wm_manifest_path(cfg, output_dir),
        load_train=load_train,
    )


def run_lifelong_training(cfg, track: str, order: str) -> Dict[str, object]:
    logger = logging.getLogger("MDReID.lifelong")
    sequence = resolve_track(track, order)
    output_dir = Path(cfg.OUTPUT_DIR).expanduser().resolve() / (
        "track_{}_{}".format(track.upper(), order.lower())
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    set_reproducible_seed(int(cfg.SOLVER.SEED))
    device = resolve_device(cfg)
    logger.info("Device: %s", device)
    logger.info("Sequence: %s", " -> ".join(sequence))

    model = LifelongMDReID(cfg).to(device)
    eval_tasks: Dict[str, EvalTask] = {}
    task_specs: List[Dict[str, object]] = []
    report: Dict[str, object] = {
        "track": track.upper(),
        "order": order.lower(),
        "sequence": sequence,
        "routing": str(cfg.LIFELONG.ROUTING),
        "scenarios": list(cfg.LIFELONG.EVAL_SCENARIOS),
        "no_replay": True,
        "checkpoint_selection": "fixed epoch; test sets are never used for model selection",
        "stages": [],
        "reserved_any_to_any": _reserved_any_to_any(),
    }

    for stage_index, dataset_name in enumerate(sequence, start=1):
        dataset_name = canonical_dataset_name(dataset_name)
        task_key = dataset_task_key(dataset_name)
        logger.info("Preparing stage %d: %s", stage_index, dataset_name)
        bundle = build_cfg_dataloaders(cfg, dataset_name, output_dir, load_train=True)
        protocol_summary = bundle.protocol.summary()
        logger.info("Protocol: %s", json.dumps(protocol_summary, ensure_ascii=False))
        model.register_task(
            task_key=task_key,
            num_classes=bundle.protocol.num_train_pids,
            initialize_from_history=True,
        )
        train_stats = train_one_task(
            cfg=cfg,
            model=model,
            task_key=task_key,
            train_loader=bundle.train_loader,
            device=device,
            logger=logger,
        )
        task_specs.append({
            "dataset": dataset_name,
            "task_key": task_key,
            "num_classes": bundle.protocol.num_train_pids,
            "target_size": list(bundle.protocol.target_size),
            "protocol": bundle.protocol.protocol,
        })
        eval_tasks[task_key] = EvalTask(
            dataset_name=dataset_name,
            task_key=task_key,
            loader=bundle.eval_loader,
            num_query=bundle.num_query,
            protocol_summary=protocol_summary,
        )

        # Explicitly release all current/old training records before evaluation.
        bundle.protocol.train.clear()
        bundle.train_loader = None
        del bundle

        candidate_tasks = [spec["task_key"] for spec in task_specs]
        dataset_results: Dict[str, Dict[str, Dict[str, float]]] = {}
        for seen_task_key, eval_task in eval_tasks.items():
            scenario_results = evaluate_scenarios(
                model=model,
                eval_task=eval_task,
                scenarios=[str(value) for value in cfg.LIFELONG.EVAL_SCENARIOS],
                candidate_tasks=candidate_tasks,
                routing=str(cfg.LIFELONG.ROUTING),
                device=device,
            )
            dataset_results[seen_task_key] = scenario_results
            for scenario, metrics in scenario_results.items():
                logger.info(
                    "stage=%d eval=%s %s mAP=%.2f R1=%.2f R5=%.2f R10=%.2f route=%.2f",
                    stage_index,
                    seen_task_key,
                    scenario,
                    metrics["mAP"],
                    metrics["R1"],
                    metrics["R5"],
                    metrics["R10"],
                    metrics["routing_accuracy"],
                )

        stage_report = {
            "stage": stage_index,
            "trained_task": task_key,
            "train_stats": train_stats,
            "protocol": protocol_summary,
            "datasets": dataset_results,
            "continual_summary": _continual_summary(
                history=report["stages"],
                current_datasets=dataset_results,
                scenarios=[str(value) for value in cfg.LIFELONG.EVAL_SCENARIOS],
            ),
            "parameter_accounting": model.parameter_accounting(),
        }
        report["stages"].append(stage_report)
        checkpoint_path = (
            output_dir / "checkpoints" / "stage_{:02d}_{}.pth".format(stage_index, task_key)
        )
        save_checkpoint(
            path=checkpoint_path,
            model=model,
            stage=stage_index,
            track=track,
            order=order,
            task_specs=task_specs,
            cfg=cfg,
        )
        stage_report["checkpoint"] = str(checkpoint_path)
        _write_reports(output_dir, report)
    return report


@torch.no_grad()
def run_lifelong_test(
    cfg,
    checkpoint_path: str,
    routing: str,
) -> Dict[str, object]:
    logger = logging.getLogger("MDReID.lifelong.test")
    device = resolve_device(cfg)
    model, checkpoint = load_checkpoint_model(cfg, checkpoint_path, device)
    task_specs = checkpoint["task_specs"]
    output_dir = Path(checkpoint_path).expanduser().resolve().parent.parent
    candidates = [str(spec["task_key"]) for spec in task_specs]
    results = {
        "checkpoint": str(Path(checkpoint_path).expanduser().resolve()),
        "stage": int(checkpoint["stage"]),
        "routing": routing,
        "datasets": {},
        "reserved_any_to_any": _reserved_any_to_any(),
    }
    for task_spec in task_specs:
        dataset_name = str(task_spec["dataset"])
        task_key = str(task_spec["task_key"])
        bundle = build_cfg_dataloaders(cfg, dataset_name, output_dir, load_train=False)
        eval_task = EvalTask(
            dataset_name=dataset_name,
            task_key=task_key,
            loader=bundle.eval_loader,
            num_query=bundle.num_query,
            protocol_summary=bundle.protocol.summary(),
        )
        results["datasets"][task_key] = {}
        scenario_results = evaluate_scenarios(
            model=model,
            eval_task=eval_task,
            scenarios=[str(value) for value in cfg.LIFELONG.EVAL_SCENARIOS],
            candidate_tasks=candidates,
            routing=routing,
            device=device,
        )
        results["datasets"][task_key] = scenario_results
        for scenario, metrics in scenario_results.items():
            logger.info(
                "%s %s mAP=%.2f R1=%.2f R5=%.2f R10=%.2f route=%.2f",
                task_key,
                scenario,
                metrics["mAP"],
                metrics["R1"],
                metrics["R5"],
                metrics["R10"],
                metrics["routing_accuracy"],
            )
    result_path = output_dir / "test_{}_stage_{:02d}.json".format(
        routing, int(checkpoint["stage"])
    )
    with result_path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(results, handle, ensure_ascii=False, indent=2)
    return results
